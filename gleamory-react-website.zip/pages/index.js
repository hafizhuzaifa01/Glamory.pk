import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function Gleamory() {
  return (
    <div className="min-h-screen bg-white text-gray-900 p-4 md:p-8 space-y-16">
      {/* Header */}
      <header className="text-center space-y-4">
        <h1 className="text-4xl font-bold">Gleamory.pk</h1>
        <p className="text-lg text-gray-600">Discover the Spark in Everyday Living</p>
      </header>

      {/* About Section */}
      <section className="max-w-3xl mx-auto text-center">
        <h2 className="text-2xl font-semibold mb-2">About Us</h2>
        <p>
          At Gleamory.pk, we aim to bring inspiration and quality together. Our platform is
          being shaped to offer products and services that bring sparkle and purpose to your lifestyle.
        </p>
      </section>

      {/* Products Section */}
      <section className="max-w-5xl mx-auto">
        <h2 className="text-2xl font-semibold text-center mb-6">Our Products (Coming Soon)</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[1, 2, 3].map((_, i) => (
            <Card key={i} className="rounded-2xl shadow-md">
              <CardContent className="p-4 text-center">
                <div className="text-gray-500">Product {i + 1}</div>
                <p className="text-sm text-gray-400">Coming Soon</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Contact Section */}
      <section className="max-w-2xl mx-auto text-center space-y-4">
        <h2 className="text-2xl font-semibold">Contact Us</h2>
        <p>Have questions? Reach out to us anytime.</p>
        <Input placeholder="Your Email" className="w-full" />
        <Button className="w-full">Send Message</Button>
      </section>

      {/* FAQ Section */}
      <section className="max-w-3xl mx-auto space-y-4">
        <h2 className="text-2xl font-semibold text-center">FAQs</h2>
        <div>
          <h3 className="font-bold">What is Gleamory.pk?</h3>
          <p>A growing online platform bringing lifestyle-inspired products and services.</p>
        </div>
        <div>
          <h3 className="font-bold">When will products be available?</h3>
          <p>We are working hard! Products will be launched very soon. Stay tuned!</p>
        </div>
      </section>

      {/* Footer */}
      <footer className="text-center text-sm text-gray-500 py-4">
        © {new Date().getFullYear()} Gleamory.pk — All rights reserved.
      </footer>
    </div>
  );
}
